extends Area2D


signal player_died
const SPEED = 100.0
var direction = -1.0
var alive = true



func _on_body_entered(body: Node2D) -> void:
	if body.name == "obj_player" and body.alive:
		emit_signal("player_died", body)
		player_died.connect(_on_player_died)
		alive = false
func _on_player_died(body):
	body.die()
	print("player killed")
