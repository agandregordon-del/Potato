extends Node2D
@onready var label: Label = $obj_player/CanvasModulate/Panel/Label

var score: int = 0



func _setup_level() -> void:
	var apples =  $Node2D.get_node_or_null("apple")
	if apples:
		for apple in apples.get_children():
			apple.collected.connect(increase_score)

# Called every frame. 'delta' is the elapsed time since the previous frame.

func increase_score() -> void:
		
	score += 1
	label.text = "SCORE: %s" % score

func _game_over():
	get_tree().reload_current_scene()
	return
	
	
