extends Node

@onready var button: Button = %Button
@onready var lev_1_complete: ColorRect = $"../lev1_complete"
@onready var lev_1_ready: ColorRect = $"../lev1_ready"
@onready var lev_2_locked: ColorRect = $"../lev2_locked"

func _ready() -> void:
	button.grab_focus()

	lev_1_ready.visible = !LevelCore.lev1_completed
	lev_2_locked.visible = !LevelCore.lev1_completed

func _on_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/node_2d.tscn")
