extends Area2D


signal player_died
const SPEED = 100.0
var direction = -1.0
var alive = true


func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.




func _on_body_shape_entered(_body_rid: RID, body: Node2D, _body_shape_index: int, _local_shape_index: int) -> void:
	if body.name == "obj_player" and body.alive:
		emit_signal("player_died", body)
		player_died.connect(_on_player_died)
		alive = false
func _on_player_died(body):
	body.die()
	print("player killed")
