extends Area2D
@onready var animated_sprite_2D: AnimatedSprite2D = $AnimatedSprite2D


signal player_died
const SPEED = 50.0
var direction = -1.0
var alive = true


func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.x += direction * SPEED * delta


func _on_timer_timeout() -> void:
	direction *= -1.0 
	animated_sprite_2D.flip_h = !animated_sprite_2D.flip_h 

func _on_body_shape_entered(_body_rid: RID, body: Node2D, _body_shape_index: int, _local_shape_index: int) -> void:
	if body.name == "obj_player" and body.alive:
		emit_signal("player_died", body)
		player_died.connect(_on_player_died)
		alive = false
func _on_player_died(body):
	body.die()
	print("player killed")
