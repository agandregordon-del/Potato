extends Node
@onready var lev_4_locked: ColorRect = $"../lev4_locked"
@onready var lev_3_ready: ColorRect = $"../lev3_ready"
@onready var lev_3_complete: ColorRect = $"../lev3_complete"
@onready var button_3: Button = %Button3


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	button_3.grab_focus()

	lev_3_ready.visible = !LevelCore.lev3_completed
	lev_4_locked.visible = !LevelCore.lev3_completed

func _on_pressed() -> void:
	if LevelCore.lev2_completed:
		get_tree().change_scene_to_file("res://level3.tscn")
