extends AnimatableBody2D

@export var point_a: Vector2 = Vector2.ZERO
@export var point_b: Vector2 = Vector2(200, 0)
@export var speed: float = 100.0

var _target: Vector2
var _direction: Vector2
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	global_position = point_a
	_target = point_b
	_direction = (_target - global_position).normalized()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	var move_vec: Vector2 = _direction * speed * delta
	var dist_to_target: float = (_target - global_position).length()
	if move_vec.length() >= dist_to_target:
		global_position = _target
		if _target == point_b:
			_target = point_a
		else:
			_target = point_b
		_direction = (_target - global_position).normalized()
	else:
		global_position += move_vec
