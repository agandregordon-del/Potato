extends Node
@onready var lev_7_ready: ColorRect = $"../lev7_ready"
@onready var lev_7_complete: ColorRect = $"../lev7_complete"
@onready var lev_8_locked: ColorRect = $"../lev8_locked"
@onready var button_7: Button = %Button7


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	button_7.grab_focus()

	lev_7_ready.visible = !LevelCore.lev7_completed
	lev_8_locked.visible = !LevelCore.lev7_completed

func _on_pressed() -> void:
	if LevelCore.lev6_completed:
		get_tree().change_scene_to_file("res://lev7.tscn")
