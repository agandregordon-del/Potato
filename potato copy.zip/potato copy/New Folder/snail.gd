extends Area2D
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D 
@onready var animated_sprite_2D: AnimatedSprite2D = $"../obj_snail/AnimatedSprite2D"

signal player_died
const SPEED = 100.0
var direction = -1.0
var alive = true


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.x += direction * SPEED * delta


func _on_timer_timeout() -> void:
	direction *= -1.0 # Replace with function body.
	animated_sprite_2d.flip_h = !animated_sprite_2d.flip_h 

func _on_body_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if body.name == "obj_player" and body.alive:
		emit_signal("player_died", body)
		player_died.connect(_on_player_died)
		
func _on_player_died(body):
	body.die()
	print("player killed")
	
func _on_timer_timeout1() -> void:
	direction *= -1.0 # Replace with function body.
	animated_sprite_2D.flip_h = !animated_sprite_2D.flip_h 
	


func _on_body1_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if body.name == "obj_player" and body.alive:
		emit_signal("player_died", body)
		player_died.connect(_on_player_died)
		
