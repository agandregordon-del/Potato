extends Node

var lev1_completed = false
var lev2_completed = false
var lev3_completed = false
var lev4_completed = false
var lev5_completed = false
var lev6_completed = false
var lev7_completed = false
var lev8_completed = false
var lev9_completed = false
var lev10_completed = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass
