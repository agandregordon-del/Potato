extends Node

@onready var lev_10_locked: ColorRect = $"../lev10_locked"
@onready var lev_9_ready: ColorRect = $"../lev9_ready"
@onready var lev_9_complete: ColorRect = $"../lev9_complete"
@onready var button_9: Button = %Button9

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	button_9.grab_focus()

	lev_9_ready.visible = !LevelCore.lev9_completed
	lev_10_locked.visible = !LevelCore.lev9_completed

func _on_pressed() -> void:
	if LevelCore.lev8_completed:
		get_tree().change_scene_to_file("res://lev9.tscn")
