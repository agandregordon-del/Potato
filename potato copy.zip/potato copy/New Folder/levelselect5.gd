extends Node
@onready var lev_5_complete: ColorRect = $"../lev5_complete"
@onready var lev_5_ready: ColorRect = $"../lev5_ready"
@onready var lev_6_locked: ColorRect = $"../lev6_locked"
@onready var button_5: Button = %Button5


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	button_5.grab_focus()

	lev_5_ready.visible = !LevelCore.lev5_completed
	lev_6_locked.visible = !LevelCore.lev5_completed

func _on_pressed() -> void:
	if LevelCore.lev4_completed:
		get_tree().change_scene_to_file("res://lev5.tscn")
