extends Node
@onready var lev_4_complete: ColorRect = $"../lev4_complete"
@onready var lev_4_ready: ColorRect = $"../lev4_ready"
@onready var lev_5_locked: ColorRect = $"../lev5_locked"
@onready var button_4: Button = %Button4


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	button_4.grab_focus()

	lev_4_ready.visible = !LevelCore.lev4_completed
	lev_5_locked.visible = !LevelCore.lev4_completed
	
func _on_pressed() -> void:
	if LevelCore.lev3_completed:
		get_tree().change_scene_to_file("res://lev4.tscn")
