extends Node
@onready var lev_6_complete: ColorRect = $"../lev6_complete"
@onready var lev_6_ready: ColorRect = $"../lev6_ready"
@onready var lev_7_locked: ColorRect = $"../lev7_locked"
@onready var button_6: Button = %Button6


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	button_6.grab_focus()

	lev_6_ready.visible = !LevelCore.lev6_completed
	lev_7_locked.visible = !LevelCore.lev6_completed

func _on_pressed() -> void:
	if LevelCore.lev5_completed:
		get_tree().change_scene_to_file("res://lev6.tscn")
