extends Node

@onready var lev_8_complete: ColorRect = $"../lev8_complete"
@onready var lev_8_ready: ColorRect = $"../lev8_ready"
@onready var lev_9_locked: ColorRect = $"../lev9_locked"
@onready var button_8: Button = %Button8

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	button_8.grab_focus()

	lev_8_ready.visible = !LevelCore.lev8_completed
	lev_9_locked.visible = !LevelCore.lev8_completed

func _on_pressed() -> void:
	if LevelCore.lev7_completed:
		get_tree().change_scene_to_file("res://lev8.tscn")
