extends Node

@onready var lev_10_complete: ColorRect = $"../lev10_complete"
@onready var lev_10_ready: ColorRect = $"../lev10_ready"
@onready var button_10: Button = %Button10

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	button_10.grab_focus()

	lev_10_ready.visible = !LevelCore.lev10_completed

func _on_pressed() -> void:
	if LevelCore.lev9_completed:
		get_tree().change_scene_to_file("res://lev10.tscn")
