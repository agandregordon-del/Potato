extends Node

@onready var button_2: Button = %Button2
@onready var lev_1_complete: ColorRect = $"../lev1_complete"
@onready var lev_2_ready: ColorRect = $"../lev2_ready"
@onready var lev_3_locked: ColorRect = $"../lev3_locked"

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	button_2.grab_focus()

	lev_2_ready.visible = !LevelCore.lev2_completed
	lev_3_locked.visible = !LevelCore.lev2_completed

func _on_pressed() -> void:
	if LevelCore.lev1_completed:
		get_tree().change_scene_to_file("res://lev2.tscn")
