extends CharacterBody2D

var alive = true
const SPEED = 300.0
const JUMP_VELOCITY = -400.0
@onready var animatedSprite2D: AnimatedSprite2D = $AnimatedSprite2D
@onready var sfx_jump = preload("uid://bfo8ljaua0fty")

	
func _physics_process(delta: float) -> void:

	if !alive:
		return
	
	if velocity.x > 1 or velocity.x < -1:
		animatedSprite2D.animation = "running"
	else:
		animatedSprite2D.animation = "idle"

	if not is_on_floor():
		velocity += get_gravity() * delta
		animatedSprite2D.animation = "jump"
	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
		

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
	
	if direction == 1.0:
		animatedSprite2D.flip_h = false
	elif direction == -1.0:
		animatedSprite2D.flip_h = true
		
func die() -> void:
	animatedSprite2D.animation = "dying"
	alive = false
	if !alive:
			get_tree().reload_current_scene()
	return
		
