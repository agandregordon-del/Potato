extends Area2D
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
@onready var collision_shape_2d: CollisionShape2D = $CollisionShape2D
var score: int = 0
signal collected
# Called when the node enters the scene tree for the first time.
@onready var label: Label = $"../../obj_player/CanvasModulate/Panel/Label"


func _on_body_entered(_body: Node2D) -> void:
	animated_sprite_2d.animation = "collected"
	collected.emit()
	call_deferred("_disable_colision")
	
func _disable_colision() -> void:
	collision_shape_2d.disabled = true

func _on_animated_sprite_2d_animation_looped() -> void:
	if animated_sprite_2d.animation == "collected":
		queue_free()

func _setup_level() -> void:
	var apples =  $Node2D.get_node_or_null("apple")
	if apples:
		for apple in apples.get_children():
			apple.collected.connect(increase_score)
			
func increase_score() -> void:
		
	score += 1
	label.text = "SCORE: %s" % score
